import React, { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getDatabase, ref, get } from "firebase/database";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAAUg8l34-ki_lKc64_zfGB7yVwvCunAKM",
    authDomain: "qiuz-47c3f.firebaseapp.com",
    databaseURL: "https://qiuz-47c3f-default-rtdb.firebaseio.com/",
    projectId: "qiuz-47c3f",
    storageBucket: "qiuz-47c3f.firebasestorage.app",
    messagingSenderId: "371167551976",
    appId: "1:371167551976:web:4e09bd7f3408f08a41045d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

const QuizApp = () => {
  const [word, setWord] = useState(null);
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState(null);
  const [correctOption, setCorrectOption] = useState(null);

  // Fetch random word from Firebase
  const fetchRandomWord = async () => {
    const wordsRef = ref(database, "user");
    const snapshot = await get(wordsRef);

    if (snapshot.exists()) {
      const words = snapshot.val();
      const wordKeys = Object.keys(words);
      const randomKey = wordKeys[Math.floor(Math.random() * wordKeys.length)];
      const randomWord = words[randomKey];

      // Prepare options (correct + random incorrect ones)
      const allMeanings = wordKeys.map((key) => words[key].Meaning);
      const incorrectOptions = allMeanings
        .filter((meaning) => meaning !== randomWord.Meaning)
        .sort(() => 0.5 - Math.random())
        .slice(0, 3);

      const shuffledOptions = [
        ...incorrectOptions,
        randomWord.Meaning,
      ].sort(() => 0.5 - Math.random());

      setWord(randomWord);
      setOptions(shuffledOptions);
      setSelectedOption(null);
      setCorrectOption(null);
    }
  };

  useEffect(() => {
    // Fetch the first word when the component loads
    fetchRandomWord();
  }, []);

  const handleOptionClick = (option) => {
    setSelectedOption(option);
    setCorrectOption(word.Meaning);
  };

  const handleNextClick = () => {
    fetchRandomWord();
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-6">Word Meaning Quiz</h1>

      {!word ? (
        <button
          onClick={fetchRandomWord}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Start Quiz
        </button>
      ) : (
        <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold mb-4">What is the meaning of "{word.Word}"?</h2>

          <div className="space-y-2">
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionClick(option)}
                className={`w-full px-4 py-2 rounded-lg text-left border transition-colors 
                  ${selectedOption === option && option === correctOption && "bg-green-200 border-green-600"} 
                  ${selectedOption === option && option !== correctOption && "bg-red-200 border-red-600"} 
                  ${selectedOption && option === correctOption && "bg-green-200 border-green-600"}
                `}
              >
                {option}
              </button>
            ))}
          </div>

          {selectedOption && selectedOption !== correctOption && (
            <p className="mt-4 text-red-600">Correct Answer: {correctOption}</p>
          )}

          <button
            onClick={handleNextClick}
            className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default QuizApp;
